-- =====================================================================
--  GLOBAL SUPERSTORE: PROFITABILITY & DISCOUNT ANALYSIS
--  20 SQL Queries across 2 Phases: KPI | Univariate
--
--  Table:   global_superstore  (51,290 rows x 24 columns)
--  Dataset: Global_Superstore2.csv
--
--  Written in MySQL syntax. Column names containing spaces (e.g. "Order ID")
--  are double-quoted, so enable ANSI_QUOTES in MySQL first (below).
--  Note: in MySQL, SUM(...)/COUNT(*) returns a decimal; on SQLite, multiply
--  by 1.0 first to avoid integer division.
-- =====================================================================

SET SESSION sql_mode = CONCAT(@@sql_mode, ',ANSI_QUOTES');

-- ---------------------------------------------------------------------
-- SETUP: create the table and load the CSV
-- ---------------------------------------------------------------------
CREATE TABLE global_superstore (
  "Row ID"          INT,
  "Order ID"        VARCHAR(30),
  "Order Date"      VARCHAR(10),   -- DD-MM-YYYY
  "Ship Date"       VARCHAR(10),   -- DD-MM-YYYY
  "Ship Mode"       VARCHAR(20),
  "Customer ID"     VARCHAR(20),
  "Customer Name"   VARCHAR(60),
  Segment           VARCHAR(20),
  City              VARCHAR(60),
  State             VARCHAR(60),
  Country           VARCHAR(60),
  "Postal Code"     VARCHAR(10),
  Market            VARCHAR(20),
  Region            VARCHAR(30),
  "Product ID"      VARCHAR(30),
  Category          VARCHAR(30),
  "Sub-Category"    VARCHAR(30),
  "Product Name"    VARCHAR(255),
  Sales             DECIMAL(12,4),
  Quantity          INT,
  Discount          DECIMAL(5,3),
  Profit            DECIMAL(12,4),
  "Shipping Cost"   DECIMAL(10,2),
  "Order Priority"  VARCHAR(20)
);

LOAD DATA LOCAL INFILE 'Global_Superstore2.csv'
INTO TABLE global_superstore
CHARACTER SET utf8mb4
FIELDS TERMINATED BY ',' OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 LINES;

-- #####################################################################
-- PHASE 1: KPI ANALYSIS  (10 headline business metrics)
-- #####################################################################

-- KPI 1 — Total Sales Revenue
-- Business question: How much total sales revenue has the company generated?
SELECT ROUND(SUM(Sales), 2) AS total_sales_revenue
FROM global_superstore;

-- KPI 2 — Total Profit
-- Business question: How much total profit has the company generated?
SELECT ROUND(SUM(Profit), 2) AS total_profit
FROM global_superstore;

-- KPI 3 — Overall Profit Margin Percentage
-- Business question: What percentage of total sales revenue was converted into profit?
SELECT ROUND(
  SUM(Profit) / NULLIF(SUM(Sales), 0) * 100, 2
) AS overall_profit_margin_percentage
FROM global_superstore;

-- KPI 4 — Average Discount Percentage
-- Business question: What is the average discount percentage applied across all sales transactions?
SELECT ROUND(AVG(Discount) * 100, 2) AS average_discount_percentage
FROM global_superstore;

-- KPI 5 — Total Number of Unique Orders
-- Business question: How many unique customer orders has the company processed?
SELECT COUNT(DISTINCT "Order ID") AS total_unique_orders
FROM global_superstore;

-- KPI 6 — Average Order Value
-- Business question: How much sales revenue does the company generate from an average customer order?
WITH order_sales AS (
  SELECT "Order ID", SUM(Sales) AS order_sales_value
  FROM global_superstore
  GROUP BY "Order ID"
)
SELECT ROUND(AVG(order_sales_value), 2) AS average_order_value
FROM order_sales;

-- KPI 7 — Percentage of Discounted Transactions
-- Business question: What percentage of sales transaction lines received a discount?
SELECT ROUND(
  SUM(CASE WHEN Discount > 0 THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0) * 100, 2
) AS discounted_transaction_percentage
FROM global_superstore;

-- KPI 8 — Loss-Making Transaction Rate
-- Business question: What percentage of sales transaction lines generated a loss?
SELECT ROUND(
  SUM(CASE WHEN Profit < 0 THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0) * 100, 2
) AS loss_making_transaction_percentage
FROM global_superstore;

-- KPI 9 — Total Loss Amount
-- Business question: What is the total monetary value lost through unprofitable transactions?
SELECT ROUND(
  ABS(SUM(CASE WHEN Profit < 0 THEN Profit ELSE 0 END)), 2
) AS total_loss_amount
FROM global_superstore;

-- KPI 10 — Discounted vs Non-Discounted Average Profit
-- Business question: How does average profit differ between discounted and non-discounted transactions?
SELECT
  ROUND(AVG(CASE WHEN Discount > 0 THEN Profit END), 2) AS average_profit_discounted,
  ROUND(AVG(CASE WHEN Discount = 0 THEN Profit END), 2) AS average_profit_not_discounted,
  ROUND(
    AVG(CASE WHEN Discount = 0 THEN Profit END) -
    AVG(CASE WHEN Discount > 0 THEN Profit END), 2
  ) AS average_profit_difference
FROM global_superstore;


-- #####################################################################
-- PHASE 2: UNIVARIATE ANALYSIS  (10 single-variable distributions)
-- #####################################################################

-- Univariate Analysis 1 — Profit Distribution Summary
-- Business question: What are the minimum, maximum and average profit values generated per transaction?
SELECT ROUND(MIN(Profit), 2) AS minimum_profit, ROUND(MAX(Profit), 2) AS maximum_profit,
       ROUND(AVG(Profit), 2) AS average_profit, ROUND(SUM(Profit), 2) AS total_profit
FROM global_superstore;

-- Univariate Analysis 2 — Profit Status Distribution
-- Business question: How many transactions were profitable, loss-making or break-even?
SELECT CASE WHEN Profit > 0 THEN 'Profitable'
            WHEN Profit < 0 THEN 'Loss-Making'
            ELSE 'Break-Even' END AS profit_status,
       COUNT(*) AS transaction_count,
       ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM global_superstore), 2) AS percentage_of_transactions
FROM global_superstore
GROUP BY profit_status
ORDER BY transaction_count DESC;

-- Univariate Analysis 3 — Discount Distribution Summary
-- Business question: What are the minimum, maximum and average discount rates applied to transactions?
SELECT ROUND(MIN(Discount) * 100, 2) AS minimum_discount_percentage,
       ROUND(MAX(Discount) * 100, 2) AS maximum_discount_percentage,
       ROUND(AVG(Discount) * 100, 2) AS average_discount_percentage
FROM global_superstore;

-- Univariate Analysis 4 — Discount Band Distribution
-- Business question: How are transactions distributed across different discount levels?
SELECT CASE WHEN Discount = 0 THEN 'No Discount'
            WHEN Discount <= 0.10 THEN 'Low Discount: 1%-10%'
            WHEN Discount <= 0.20 THEN 'Moderate Discount: 11%-20%'
            WHEN Discount <= 0.40 THEN 'High Discount: 21%-40%'
            ELSE 'Very High Discount: Above 40%' END AS discount_band,
       COUNT(*) AS transaction_count,
       ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM global_superstore), 2) AS percentage_of_transactions
FROM global_superstore
GROUP BY discount_band
ORDER BY transaction_count DESC;

-- Univariate Analysis 5 — Sales Value Distribution Summary
-- Business question: What are the lowest, highest and average transaction sales values?
SELECT ROUND(MIN(Sales), 2) AS minimum_sales_value, ROUND(MAX(Sales), 2) AS maximum_sales_value,
       ROUND(AVG(Sales), 2) AS average_sales_value, ROUND(SUM(Sales), 2) AS total_sales_value
FROM global_superstore;

-- Univariate Analysis 6 — Sales Value Band Distribution
-- Business question: How many transactions fall into low, medium, high and very high sales-value groups?
SELECT CASE WHEN Sales < 100 THEN 'Low Sales: Below 100'
            WHEN Sales < 500 THEN 'Medium Sales: 100-499'
            WHEN Sales < 1000 THEN 'High Sales: 500-999'
            ELSE 'Very High Sales: 1000 and Above' END AS sales_band,
       COUNT(*) AS transaction_count,
       ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM global_superstore), 2) AS percentage_of_transactions
FROM global_superstore
GROUP BY sales_band
ORDER BY transaction_count DESC;

-- Univariate Analysis 7 — Quantity Distribution
-- Business question: What quantities are most frequently purchased in individual transaction lines?
SELECT Quantity, COUNT(*) AS transaction_count,
       ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM global_superstore), 2) AS percentage_of_transactions
FROM global_superstore
GROUP BY Quantity
ORDER BY transaction_count DESC;

-- Univariate Analysis 8 — Category Frequency Distribution
-- Business question: Which product categories appear most frequently in sales transactions?
SELECT Category, COUNT(*) AS transaction_count,
       ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM global_superstore), 2) AS percentage_of_transactions
FROM global_superstore
GROUP BY Category
ORDER BY transaction_count DESC;

-- Univariate Analysis 9 — Sub-Category Frequency Distribution
-- Business question: Which product sub-categories are purchased most frequently?
SELECT "Sub-Category", COUNT(*) AS transaction_count,
       ROUND(COUNT(*) * 100.0 / (SELECT COUNT(*) FROM global_superstore), 2) AS percentage_of_transactions
FROM global_superstore
GROUP BY "Sub-Category"
ORDER BY transaction_count DESC;

-- Univariate Analysis 10 — Profit Quartile Distribution
-- Business question: How are transactions distributed across four profitability groups from the lowest profit to the highest profit?
WITH profit_quartiles AS (
  SELECT Profit, NTILE(4) OVER (ORDER BY Profit) AS profit_quartile
  FROM global_superstore
)
SELECT profit_quartile, COUNT(*) AS transaction_count,
       ROUND(MIN(Profit), 2) AS minimum_profit, ROUND(MAX(Profit), 2) AS maximum_profit,
       ROUND(AVG(Profit), 2) AS average_profit
FROM profit_quartiles
GROUP BY profit_quartile
ORDER BY profit_quartile;

-- =====================================================================
--  END OF FILE — 20 queries total
-- =====================================================================
